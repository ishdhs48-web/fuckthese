#include "esp.h"
#include "sdk.h"
#include "holy/ui/cfg.hpp"
#include "game/game.hpp"
#include "game/player.hpp"
#include "math.hpp"
#include "imgui.h"
#include "Android_draw/draw.h"
#include "other/custom_string.h"
#include <cmath>
#include <cstdio>
#include <cstring>
#include <chrono>
#include <unordered_map>
#include "logger.h"

namespace esp {

    static ImU32 to_u32(const ImVec4& c, float a = 1.f) {
        return IM_COL32((int)(c.x * 255.f), (int)(c.y * 255.f), (int)(c.z * 255.f), (int)(c.w * 255.f * a));
    }

    static bool any_esp_on() {
        return cfg::esp::box || cfg::esp::name ||
               cfg::esp::health || cfg::esp::distance ||
               cfg::esp::snapline || cfg::esp::head_dot;
    }

    // cached photon data (hp/name/visible are SLOW walks — don't do them every frame)
    struct cached_t {
        int hp = -1;
        char name[48] = {};
        bool visible = false;
        bool valid = false;
        std::chrono::steady_clock::time_point ts;

        // bones read throttling (the real perf hog)
        Vec3 bones[22] = {};
        bool bones_ok = false;
        std::chrono::steady_clock::time_point bones_ts{};
    };
    static constexpr int BONES_TTL_MS = 40; // ~25 Гц обновления костей
    static std::unordered_map<uint64_t, cached_t> g_cache;
    static constexpr int CACHE_TTL_MS = 250;

    // stale-bones detector: if root moves but head bone frozen, game stopped animating (invisible)
    struct stale_t {
        Vec3 last_head{};
        Vec3 last_root{};
        int frames = 0; // consecutive frames with frozen bones
    };
    static std::unordered_map<uint64_t, stale_t> g_stale;

    static bool likely_ptr(uint64_t p) {
        return p > 0x10000ull && p < 0x0000FFFFFFFFFFFFull;
    }

    // ---- sticky caches: reading can transiently fail (game re-allocates),
    // so we keep last-good values instead of flickering ----

    static uint64_t g_pm_cached = 0;
    static std::chrono::steady_clock::time_point g_pm_last_ok{};
    static constexpr int PM_GRACE_MS = 1500;

    static uint64_t g_lp_cached = 0;
    static std::chrono::steady_clock::time_point g_lp_last_ok{};
    static constexpr int LP_GRACE_MS = 1000;

    static matrix g_vm_cached = {};
    static bool g_vm_have = false;

    // lock dictionary layout after first successful parse
    static int g_dict_layout = 0; // 0=unknown, 1=new(entries 0x20,count 0x24), 2=old(entries 0x18,count 0x20)

    static bool validate_pm(uint64_t pm) {
        if (!likely_ptr(pm)) return false;
        uint64_t dict = rpm<uint64_t>(pm + sdk::PM_Dict);
        if (!likely_ptr(dict)) return false;
        uint64_t lp = rpm<uint64_t>(pm + sdk::PM_LocalPlayer);
        return likely_ptr(lp);
    }

    static uint64_t pm_stable() {
        uint64_t pm = get_player_manager();
        auto now = std::chrono::steady_clock::now();
        if (validate_pm(pm)) {
            if (pm != g_pm_cached) {
                logger::log("esp: pm updated 0x%llx -> 0x%llx",
                            (unsigned long long)g_pm_cached, (unsigned long long)pm);
                g_pm_cached = pm;
            }
            g_pm_last_ok = now;
            return g_pm_cached;
        }
        if (g_pm_cached &&
            std::chrono::duration_cast<std::chrono::milliseconds>(now - g_pm_last_ok).count() < PM_GRACE_MS &&
            validate_pm(g_pm_cached)) {
            if (logger::throttle("pm_cached", 2000)) logger::log("esp: using cached pm=0x%llx", (unsigned long long)g_pm_cached);
            return g_pm_cached;
        }
        g_pm_cached = 0;
        return 0;
    }

    static uint64_t lp_stable(uint64_t pm) {
        uint64_t lp = rpm<uint64_t>(pm + sdk::PM_LocalPlayer);
        auto now = std::chrono::steady_clock::now();
        if (likely_ptr(lp)) {
            if (lp != g_lp_cached)
                logger::log("esp: lp updated 0x%llx -> 0x%llx",
                            (unsigned long long)g_lp_cached, (unsigned long long)lp);
            g_lp_cached = lp;
            g_lp_last_ok = now;
            return lp;
        }
        if (g_lp_cached &&
            std::chrono::duration_cast<std::chrono::milliseconds>(now - g_lp_last_ok).count() < LP_GRACE_MS) {
            int t = rpm<uint8_t>(g_lp_cached + sdk::PC_TEAM);
            if (t >= 0 && t <= 3) {
                if (logger::throttle("lp_cached", 2000)) logger::log("esp: using cached lp=0x%llx", (unsigned long long)g_lp_cached);
                return g_lp_cached;
            }
        }
        g_lp_cached = 0;
        return 0;
    }
    static int collect_players(uint64_t pm, uint64_t* out, int max) {
        uint64_t dict = rpm<uint64_t>(pm + sdk::PM_Dict);
        if (!likely_ptr(dict)) return 0;

        int count = 0;
        uint64_t entries = 0;

        if (g_dict_layout == 2) { // locked: old
            count = rpm<int>(dict + 0x20);
            entries = rpm<uint64_t>(dict + 0x18);
        } else if (g_dict_layout == 1) { // locked: new
            count = rpm<int>(dict + 0x24);
            entries = rpm<uint64_t>(dict + 0x20);
        } else { // detect once
            int count_old = rpm<int>(dict + 0x20);
            int count_new = rpm<int>(dict + 0x24);
            uint64_t entries_old = rpm<uint64_t>(dict + 0x18);
            uint64_t entries_new = rpm<uint64_t>(dict + 0x20);
            if (likely_ptr(entries_new) && count_new > 0 && count_new <= 16) {
                count = count_new; entries = entries_new; g_dict_layout = 1;
                logger::log("esp: dict layout = NEW (entries 0x20, count 0x24)");
            } else if (likely_ptr(entries_old) && count_old > 0 && count_old <= 16) {
                count = count_old; entries = entries_old; g_dict_layout = 2;
                logger::log("esp: dict layout = OLD (entries 0x18, count 0x20)");
            } else if (likely_ptr(entries_new) && count_new > 0 && count_new <= 64) {
                count = count_new; entries = entries_new; g_dict_layout = 1;
                logger::log("esp: dict layout = NEW(relaxed)");
            } else if (likely_ptr(entries_old) && count_old > 0 && count_old <= 64) {
                count = count_old; entries = entries_old; g_dict_layout = 2;
                logger::log("esp: dict layout = OLD(relaxed)");
            }
        }
        if (!likely_ptr(entries) || count <= 0 || count > 64) return 0;

        int n = 0;
        for (int i = 0; i < count && n < max; i++) {
            uint64_t p = rpm<uint64_t>(entries + sdk::ARRAY_DATA + sdk::DICT_ENTRY_VAL + sdk::DICT_ENTRY_SZ * i);
            if (likely_ptr(p)) out[n++] = p;
        }
        return n;
    }

    static void draw_player(ImDrawList* dl, const PlayerData& pd, const Vector3& lp_pos, const matrix& vm, int lt) {
        if (pd.team == lt) {
            return;
        }
        if (pd.hp >= 0 && pd.hp <= 0) {
            return;
        }

        ImVec2 foot, head;

        // box from feet(0) to head+0.25
        Vector3 root_pos = player::position(pd.base);
        if (root_pos.x == 0 && root_pos.y == 0 && root_pos.z == 0) return;

        float d = sqrtf(powf(root_pos.x - lp_pos.x, 2) + powf(root_pos.y - lp_pos.y, 2) + powf(root_pos.z - lp_pos.z, 2));
        if (d > 300.f) {
            return;
        }

        Vector3 head_pos(root_pos.x, root_pos.y + 1.85f, root_pos.z);
        if (!world_to_screen(root_pos, vm, foot) || !world_to_screen(head_pos, vm, head)) {
            if (logger::throttle("skip_w2s", 5000)) logger::log("esp: p=0x%llx skipped (w2s fail)", (unsigned long long)pd.base);
            return;
        }

        float h = foot.y - head.y;
        if (h < 4.f) return;
        float w = h * 0.42f;
        float x = head.x - w * 0.5f;

        ImU32 col = to_u32(cfg::esp::box_col, 0.92f);
        ImFont* f = espFont ? espFont : ImGui::GetFont();

        if (cfg::esp::head_dot && pd.bones_ok) {
            ImVec2 hp2;
            if (world_to_screen(Vector3(pd.bones[0].x, pd.bones[0].y, pd.bones[0].z), vm, hp2)) {
                dl->AddCircleFilled(hp2, 4.f, to_u32(cfg::esp::head_dot_col), 16);
            }
        }

        if (cfg::esp::box) {
            if (cfg::esp::box_type == 1) {
                // corner box
                float ch = h * 0.25f, cw = w * 0.35f;
                float t = 1.8f;
                dl->AddLine(ImVec2(x, head.y + ch), ImVec2(x, head.y), col, t);
                dl->AddLine(ImVec2(x, head.y), ImVec2(x + cw, head.y), col, t);
                dl->AddLine(ImVec2(x + w - cw, head.y), ImVec2(x + w, head.y), col, t);
                dl->AddLine(ImVec2(x + w, head.y), ImVec2(x + w, head.y + ch), col, t);
                dl->AddLine(ImVec2(x, foot.y - ch), ImVec2(x, foot.y), col, t);
                dl->AddLine(ImVec2(x, foot.y), ImVec2(x + cw, foot.y), col, t);
                dl->AddLine(ImVec2(x + w - cw, foot.y), ImVec2(x + w, foot.y), col, t);
                dl->AddLine(ImVec2(x + w, foot.y - ch), ImVec2(x + w, foot.y), col, t);
            } else {
                dl->AddRect(ImVec2(x, head.y), ImVec2(x + w, foot.y), col, cfg::esp::box_rounding, 0, 1.6f);
            }
        }

        if (cfg::esp::health) {
            float hp_frac = pd.hp > 0 ? (pd.hp > 100 ? 1.f : pd.hp / 100.f) : 0.f;
            ImU32 hc = to_u32(cfg::esp::health_col, 0.95f);
            dl->AddRectFilled(ImVec2(x - 5.f, foot.y), ImVec2(x - 2.f, head.y), IM_COL32(0, 0, 0, 150));
            dl->AddRectFilled(ImVec2(x - 5.f, foot.y - (foot.y - head.y) * hp_frac), ImVec2(x - 2.f, foot.y), hc);
        }

        if (cfg::esp::name && pd.name[0]) {
            ImVec2 ts = f->CalcTextSizeA(16.f, FLT_MAX, 0, pd.name);
            dl->AddText(f, 16.f, ImVec2(head.x - ts.x * 0.5f, head.y - ts.y - 3.f), to_u32(cfg::esp::name_col, 0.86f), pd.name);
        }

        if (cfg::esp::distance) {
            char db[24];
            snprintf(db, sizeof(db), "[%.0fm]", d);
            ImVec2 ts = f->CalcTextSizeA(15.f, FLT_MAX, 0, db);
            dl->AddText(f, 15.f, ImVec2(foot.x - ts.x * 0.5f, foot.y + 3.f), to_u32(cfg::esp::distance_col, 0.86f), db);
        }

        if (cfg::esp::snapline) {
            float ly = cfg::esp::snapline_head ? 0.f : g_sh;
            ImVec2 to = cfg::esp::snapline_head ? head : foot;
            dl->AddLine(ImVec2(g_sw * 0.5f, ly), to, to_u32(cfg::esp::snapline_col, 0.5f), 1.2f);
        }
    }

    void frame() {
        if (!any_esp_on()) return;

        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        if (!dl) return;

        uint64_t pm = pm_stable();
        if (!pm) {
            static int pm_fail = 0;
            if (++pm_fail >= 300) { pm_fail = 0; logger::log("esp: pm=0 (PlayerManager not found)"); }
            return;
        }

        uint64_t lp = lp_stable(pm);
        if (!lp) {
            if (logger::throttle("esp_no_lp", 2000)) logger::log("esp: local player = 0");
            return;
        }

        matrix vm = player::view_matrix(lp);
        // cache last-good matrix: transient zero reads shouldn't kill the frame
        if (vm.m11 == 0.f && vm.m22 == 0.f && vm.m33 == 0.f) {
            if (g_vm_have) {
                vm = g_vm_cached;
                if (logger::throttle("esp_vm_cached", 3000)) logger::log("esp: using cached view matrix");
            } else {
                static int vm_fail = 0;
                if (++vm_fail >= 300) { vm_fail = 0; logger::log("esp: invalid view matrix (camera chain failed)"); }
                return;
            }
        } else {
            g_vm_cached = vm;
            g_vm_have = true;
        }

        int lt = rpm<uint8_t>(lp + sdk::PC_TEAM);
        Vector3 lp_pos = player::position(lp);

        uint64_t list[64];
        int n = collect_players(pm, list, 64);

        // log player-count changes
        static int last_logged_n = -1;
        if (n != last_logged_n) {
            uint64_t dict = rpm<uint64_t>(pm + sdk::PM_Dict);
            logger::log("esp: %d players in list (dict=0x%llx)", n, (unsigned long long)dict);
            last_logged_n = n;
        }

        auto now = std::chrono::steady_clock::now();

        // refresh cache for all players first (cheap), draw after
        for (int i = 0; i < n; i++) {
            uint64_t p = list[i];
            if (!likely_ptr(p) || p == lp) continue;
            auto& c = g_cache[p];
            if (c.valid && std::chrono::duration_cast<std::chrono::milliseconds>(now - c.ts).count() < CACHE_TTL_MS) {
                // still fetch live bones at throttled rate
                if (std::chrono::duration_cast<std::chrono::milliseconds>(now - c.bones_ts).count() >= BONES_TTL_MS) {
                    player::bones_t bones;
                    if (player::get_bones(p, bones)) {
                        Vector3 r = player::position(p);
                        auto& st = g_stale[p];
                        float head_dr = sqrtf(powf(bones[0].x - st.last_head.x, 2) + powf(bones[0].y - st.last_head.y, 2) + powf(bones[0].z - st.last_head.z, 2));
                        float root_dr = sqrtf(powf(r.x - st.last_root.x, 2) + powf(r.y - st.last_root.y, 2) + powf(r.z - st.last_root.z, 2));
                        if (root_dr > 0.002f && head_dr < 0.0005f) st.frames++; else st.frames = 0;
                        if (st.frames > 5) {
                            player::apply_default_pose(bones, r);
                            if (logger::throttle("esp_stale", 4000))
                                logger::log("esp: bones frozen for 0x%llx, using default pose", (unsigned long long)p);
                        }
                        st.last_head = { bones[0].x, bones[0].y, bones[0].z };
                        st.last_root = { r.x, r.y, r.z };
                        for (int b = 0; b < 22; b++) c.bones[b] = { bones[b].x, bones[b].y, bones[b].z };
                        c.bones_ok = true;
                        c.bones_ts = now;
                    }
                }
                continue;
            }

            c.hp = player::health(p);
            read_string nm = player::name(p);
            std::string u8 = nm.as_utf8();
            strncpy(c.name, u8.c_str(), sizeof(c.name) - 1);
            c.name[sizeof(c.name) - 1] = 0;
            c.visible = player::is_visible(p);
            c.ts = now;
            c.valid = true;

            // initial bones read for this player
            player::bones_t bones;
            if (player::get_bones(p, bones)) {
                for (int b = 0; b < 22; b++) c.bones[b] = { bones[b].x, bones[b].y, bones[b].z };
                c.bones_ok = true;
                c.bones_ts = now;
            }
        }

        // prune stale entries
        if (g_cache.size() > 128) {
            for (auto it = g_cache.begin(); it != g_cache.end();) {
                if (std::chrono::duration_cast<std::chrono::milliseconds>(now - it->second.ts).count() > 5000) it = g_cache.erase(it);
                else ++it;
            }
        }

        for (int i = 0; i < n; i++) {
            uint64_t p = list[i];
            if (!likely_ptr(p) || p == lp) continue;

            PlayerData pd;
            pd.base = p;
            pd.team = rpm<uint8_t>(p + sdk::PC_TEAM);

            auto it = g_cache.find(p);
            if (it != g_cache.end() && it->second.valid) {
                pd.hp = it->second.hp;
                strncpy(pd.name, it->second.name, sizeof(pd.name));
                pd.visible = it->second.visible;
            } else {
                pd.hp = player::health(p);
                read_string nm = player::name(p);
                std::string u8 = nm.as_utf8();
                strncpy(pd.name, u8.c_str(), sizeof(pd.name) - 1);
                pd.visible = player::is_visible(p);
            }

            auto b_it = g_cache.find(p);
            if (b_it != g_cache.end() && b_it->second.valid) {
                pd.bones_ok = b_it->second.bones_ok;
                for (int b = 0; b < 22; b++) pd.bones[b] = b_it->second.bones[b];
            } else {
                player::bones_t bones;
                if (player::get_bones(p, bones)) {
                    pd.bones_ok = true;
                    for (int b = 0; b < 22; b++) pd.bones[b] = { bones[b].x, bones[b].y, bones[b].z };
                } else if (logger::throttle("esp_bones", 3000)) {
                    logger::log("esp: bones read failed for player 0x%llx", (unsigned long long)p);
                }
            }

            if (logger::throttle("esp_player_dump", 5000)) {
                logger::log("esp: p=0x%llx team=%d hp=%d vis=%d bones_ok=%d name='%s'",
                            (unsigned long long)p, pd.team, pd.hp, pd.visible ? 1 : 0, pd.bones_ok ? 1 : 0, pd.name);
            }

            draw_player(dl, pd, lp_pos, vm, lt);
            skip_esp:;
        }
    }

} // namespace esp
