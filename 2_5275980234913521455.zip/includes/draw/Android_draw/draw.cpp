#include "Android_draw/draw.h"
#include "fonts/menu/pixeloperator.h"
#include "fonts/esp/esp.h"
#include "fonts/inter.h"
#include "logger.h"
// teamratko: no ui/menu.hpp (nez3rpw-only); init_fonts stubbed below
namespace ui { namespace draw { inline void init_fonts() {} } }

EGLDisplay display = EGL_NO_DISPLAY;
EGLConfig config;
EGLSurface surface = EGL_NO_SURFACE;
EGLContext context = EGL_NO_CONTEXT;

ANativeWindow *native_window;
// Old fonts (kept for compatibility with legacy code that might still use them)
ImFont* fontBold = nullptr;
ImFont* fontMedium = nullptr;
ImFont* fontDesc = nullptr;
ImFont* espFont = nullptr;

int native_window_screen_x = 0;
int native_window_screen_y = 0;
android::ANativeWindowCreator::DisplayInfo displayInfo{0};
uint32_t orientation = 0;
bool g_Initialized = false;
ImGuiWindow *g_window = nullptr;

bool initGUI_draw(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    orientation = displayInfo.orientation;

    if (!init_egl(_screen_x, _screen_y, log)) {
        return false;
    }

    if (!ImGui_init()) {
        return false;
    }

    return true;
}

bool init_egl(uint32_t _screen_x, uint32_t _screen_y, bool log) {
    ::native_window = android::ANativeWindowCreator::Create("Overlay", _screen_x, _screen_y, false);
    if (!::native_window) {
        if (log) logger::log("FATAL-step: ANativeWindowCreator::Create failed");
        return false;
    }
    if (log) logger::log("egl: window ok %p", (void*)::native_window);

    ANativeWindow_acquire(native_window);
    display = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (display == EGL_NO_DISPLAY) {
        if (log) logger::log("FATAL-step: eglGetDisplay failed");
        return false;
    }

    if (eglInitialize(display, 0, 0) != EGL_TRUE) {
        if (log) logger::log("FATAL-step: eglInitialize failed");
        return false;
    }
    if (log) logger::log("egl: initialized");

    EGLint num_config = 0;

    // try a range of configs: strict -> relaxed, ES2/ES3 renderable, any depth/stencil
    struct CfgTry { const EGLint* attrs; const char* name; };
    const EGLint cfg_strict[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, 0x0004, // ES2 bit
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_DEPTH_SIZE, 16, EGL_STENCIL_SIZE, 8,
        EGL_NONE
    };
    const EGLint cfg_no_depth[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, 0x0004,
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    const EGLint cfg_rgb565[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, 0x0004,
        EGL_RED_SIZE, 5, EGL_GREEN_SIZE, 6, EGL_BLUE_SIZE, 5,
        EGL_NONE
    };
    const EGLint cfg_any[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_NONE
    };
    const EGLint cfg_es3[] = {
        EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
        EGL_RENDERABLE_TYPE, 0x0040, // ES3 bit
        EGL_RED_SIZE, 8, EGL_GREEN_SIZE, 8, EGL_BLUE_SIZE, 8, EGL_ALPHA_SIZE, 8,
        EGL_NONE
    };
    const CfgTry tries[] = {
        { cfg_es3,      "es3-8888" },
        { cfg_strict,   "strict-8888" },
        { cfg_no_depth, "no-depth-8888" },
        { cfg_rgb565,   "rgb565" },
        { cfg_any,      "any" },
    };

    bool cfg_ok = false;
    for (auto& t : tries) {
        if (eglChooseConfig(display, t.attrs, &config, 1, &num_config) == EGL_TRUE && num_config > 0) {
            if (log) logger::log("egl: config ok (%s)", t.name);
            cfg_ok = true;
            break;
        }
    }
    if (!cfg_ok) {
        if (log) logger::log("FATAL-step: eglChooseConfig failed (err=0x%x)", eglGetError());
        return false;
    }

    const EGLint attrib_list[] = {
        EGL_CONTEXT_CLIENT_VERSION,
        3,
        EGL_NONE
    };

    EGLint egl_format;
    eglGetConfigAttrib(display, config, EGL_NATIVE_VISUAL_ID, &egl_format);
    ANativeWindow_setBuffersGeometry(native_window, 0, 0, egl_format);
    context = eglCreateContext(display, config, EGL_NO_CONTEXT, attrib_list);
    if (context == EGL_NO_CONTEXT) {
        if (log) logger::log("FATAL-step: eglCreateContext failed (err=0x%x)", eglGetError());
        return false;
    }
    if (log) logger::log("egl: context ok");

    surface = eglCreateWindowSurface(display, config, native_window, nullptr);
    if (surface == EGL_NO_SURFACE) {
        if (log) logger::log("FATAL-step: eglCreateWindowSurface failed (err=0x%x)", eglGetError());
        return false;
    }
    if (log) logger::log("egl: surface ok");

    if (!eglMakeCurrent(display, surface, surface, context)) {
        if (log) logger::log("FATAL-step: eglMakeCurrent failed (err=0x%x)", eglGetError());
        return false;
    }
    if (log) logger::log("egl: makeCurrent ok");

    return true;
}

void screen_config() {
    displayInfo = android::ANativeWindowCreator::GetDisplayInfo();
}

bool ImGui_init() {
    if (g_Initialized) {
        return true;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplAndroid_Init(native_window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    ImGuiIO &io = ImGui::GetIO();
    io.IniFilename = NULL;

    // menu font scale: reference is a 1080p-landscape phone (1920x1080).
    // scale from the SHORT side (real screen height in landscape), not the window square.
    float fs = 1.f;
    {
        int sh = displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width;
        if (sh > 1080) fs = (float)sh / 1080.f;
        if (sh < 800) fs = (float)sh / 800.f; // small phones: shrink too
        if (fs > 2.2f) fs = 2.2f;
        if (fs < 0.7f) fs = 0.7f;
    }

    // Carbon menu fonts (inter, latin only — menu text is english)
    fontBold = io.Fonts->AddFontFromMemoryTTF(inter, sizeof(inter), 32.f * fs, nullptr, io.Fonts->GetGlyphRangesDefault());
    fontMedium = io.Fonts->AddFontFromMemoryTTF(inter, sizeof(inter), 28.f * fs, nullptr, io.Fonts->GetGlyphRangesDefault());
    fontDesc = io.Fonts->AddFontFromMemoryTTF(inter, sizeof(inter), 22.f * fs, nullptr, io.Fonts->GetGlyphRangesDefault());
    io.FontDefault = fontMedium;

    // esp font for player names (cyrillic-capable)
    espFont = io.Fonts->AddFontFromMemoryTTF(esp, sizeof(esp), 24.f * fs, nullptr, io.Fonts->GetGlyphRangesCyrillic());

    // Initialize new menu fonts early
    ui::draw::init_fonts();

    ::g_Initialized = true;
    return true;
}

void drawBegin() {
    screen_config();
    if (::orientation != displayInfo.orientation) {
        ::orientation = displayInfo.orientation;
        touch::update(displayInfo.width, displayInfo.height, displayInfo.orientation);
        if (g_window) {
            g_window->Pos.x = 100;
            g_window->Pos.y = 125;
        }
    }

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(native_window_screen_x, native_window_screen_y);
    ImGui::NewFrame();
}

void drawEnd() {
    ImGui::Render();
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(display, surface);
}

void shutdown() {
    if (!g_Initialized) {
        return;
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();

    if (display != EGL_NO_DISPLAY) {
        eglMakeCurrent(display, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (context != EGL_NO_CONTEXT) {
            eglDestroyContext(display, context);
        }
        if (surface != EGL_NO_SURFACE) {
            eglDestroySurface(display, surface);
        }
        eglTerminate(display);
    }
    display = EGL_NO_DISPLAY;
    context = EGL_NO_CONTEXT;
    surface = EGL_NO_SURFACE;

    ANativeWindow_release(native_window);
    android::ANativeWindowCreator::Destroy(native_window);
    ::g_Initialized = false;
}
