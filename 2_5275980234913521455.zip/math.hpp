#pragma once
#include "other/vector3.h"
#include "imgui.h"
#include <cstdint>

extern float g_sw, g_sh; // defined in main.cpp

struct matrix; // defined in game/game.hpp

//nez3rpw-proven W2S (v0.39.2 native camera matrix @ 0xF0)
inline bool world_to_screen(const Vector3& pos, const matrix& m, ImVec2& out)
{
    float sx = m.m11 * pos.x + m.m21 * pos.y + m.m31 * pos.z + m.m41;
    float sy = m.m12 * pos.x + m.m22 * pos.y + m.m32 * pos.z + m.m42;
    float sw = m.m14 * pos.x + m.m24 * pos.y + m.m34 * pos.z + m.m44;
    if (sw <= 0.0001f) return false;
    float iw = 1.f / sw;
    out.x = ((sx * iw) + 1.f) * 0.5f * g_sw;
    out.y = (1.f - (sy * iw)) * 0.5f * g_sh;
    return true;
}
