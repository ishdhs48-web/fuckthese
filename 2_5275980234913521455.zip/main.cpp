#include "includes/internal/Android_draw/draw.h"
#include "includes/internal/ImGui/imgui.h"
#include "logger.h"
#include "holy/ui/menu.hpp"
#include "holy/ui/bar.hpp"
#include "holy/ui/cfg.hpp"
#include "esp.h"
#include "aim.h"
#include "game/game.hpp"
#include "other/memory.hpp"
#include "protect/oxorany.hpp"
#include <cstdio>
#include <thread>
#include <chrono>

float g_sw = 0.f, g_sh = 0.f;

static void print_status(const char* status) {
    logger::log("%s", status);
}

int main() {
    logger::init();
    screen_config();
    logger::log("boot: screen %dx%d", displayInfo.width, displayInfo.height);

    int max_size = (displayInfo.height > displayInfo.width ? displayInfo.height : displayInfo.width);
    int min_size = (displayInfo.height < displayInfo.width ? displayInfo.height : displayInfo.width);

    g_sw = static_cast<float>(max_size);
    g_sh = static_cast<float>(min_size);

    native_window_screen_x = max_size;
    native_window_screen_y = max_size;

    if (!initGUI_draw(native_window_screen_x, native_window_screen_y, true)) {
        logger::log("FATAL: initGUI_draw failed");
        return -1;
    }
    logger::log("overlay initialized (%dx%d)", native_window_screen_x, native_window_screen_y);

    touch::init(max_size, min_size, (uint8_t)displayInfo.orientation);
    logger::log("touch initialized");

    print_status(oxorany("waiting for game..."));
    game::init();

    static bool prev = false;
    static bool game_started = false;

    while (true) {
        drawBegin();

        bool run = game::valid();

        // unconditional heartbeat every few seconds so we can verify logging works
        if (logger::throttle("heartbeat", 3000))
            logger::log("tick: loop alive, menu_open=%d, run=%d", ui::bar::g_open ? 1 : 0, run ? 1 : 0);

        bool is_landscape = (displayInfo.orientation == 1 || displayInfo.orientation == 3);

        if (run && !prev) {
            if (!game_started) {
                print_status(oxorany("game detected"));
                game_started = true;
            }
            prev = true;
        } else if (!run && prev) {
            print_status(oxorany("game closed"));
            prev = false;
            game_started = false;
        }
        if (is_landscape) {
            // dim background only while the game is actually running
            ui::bar::set_game_alpha(run ? 1.f : 0.f);

            // holy menu: bar pill + watermark + window all in one
            ui::menu::render();
            ui::menu::render_watermark(1.f);

            if (ui::menu::should_exit()) {
                logger::log("ui: unload requested -> exiting");
                shutdown();
                return 0;
            }

            if (run && proc::lib != 0) {
                uint64_t pm = get_player_manager();
                game::check_lib(pm);

                // one-shot log of key pointers when game connects
                static bool logged_once = false;
                if (!logged_once && pm) {
                    logged_once = true;
                    logger::log("pid=%d lib=0x%llx pm=0x%llx", proc::pid,
                                (unsigned long long)proc::lib, (unsigned long long)pm);
                    uint64_t lp = rpm<uint64_t>(pm + 0x70);
                    logger::log_ptr("local player", lp);
                }

                esp::frame();
                aim::run();
                aim::draw_fov(ImGui::GetBackgroundDrawList(), g_sw, g_sh);
            } else if (run && proc::lib == 0) {
                if (logger::throttle("no_lib", 3000)) logger::log("main: game running but lib=0 (rescanning)");
            }
        }

        bool vis = ui::bar::g_open;
        drawEnd();
        usleep(vis ? 1500 : 4000);
    }

    shutdown();
    return 0;
}
