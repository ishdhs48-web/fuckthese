#pragma once
#include <cstdint>
#include <vector>

namespace esp {

struct Vec3 { float x, y, z; };

struct PlayerData {
    uint64_t base = 0, photon = 0;
    uint8_t team = 0;
    int hp = -1, armor = -1;
    char name[48] = {};
    Vec3 bones[22] = {};
    bool bones_ok = false;
    bool visible = false;
};

// called every frame before rendering
void frame();

} // namespace esp
