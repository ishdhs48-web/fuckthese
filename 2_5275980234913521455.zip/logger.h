#pragma once

#include <cstdio>
#include <cstdarg>
#include <ctime>
#include <string>
#include <unordered_map>
#include <sys/time.h>
#include "protect/oxorany.hpp"

namespace logger {

    inline FILE* g_file = nullptr;

    inline void init() {
        if (g_file) return;
        g_file = fopen(oxorany("/data/local/tmp/tr.log"), "w");
        if (g_file) {
            setvbuf(g_file, nullptr, _IOLBF, 512);
            fprintf(g_file, "[init] TeamRatko started\n");
        }
    }

    inline void log(const char* fmt, ...) {
        struct timeval tv;
        gettimeofday(&tv, nullptr);
        struct tm tmv;
        time_t t = tv.tv_sec;
        localtime_r(&t, &tmv);

        char prefix[40];
        snprintf(prefix, sizeof(prefix), "[%02d:%02d:%02d.%03d] ",
                 tmv.tm_hour, tmv.tm_min, tmv.tm_sec, (int)(tv.tv_usec / 1000));

        char msg[512];
        va_list ap;
        va_start(ap, fmt);
        vsnprintf(msg, sizeof(msg), fmt, ap);
        va_end(ap);

        printf("%s%s\n", prefix, msg);
        if (g_file) {
            fprintf(g_file, "%s%s\n", prefix, msg);
            fflush(g_file);
        }
    }

    inline void log_ptr(const char* label, uint64_t v) {
        log("%s: 0x%llx", label, (unsigned long long)v);
    }

    // rate-limited log: returns true once per `ms` for a given tag
    inline bool throttle(const char* tag, int ms) {
        static std::unordered_map<std::string, long long> last;
        struct timeval tv;
        gettimeofday(&tv, nullptr);
        long long now = (long long)tv.tv_sec * 1000 + tv.tv_usec / 1000;
        auto it = last.find(tag);
        if (it != last.end() && now - it->second < ms) return false;
        last[tag] = now;
        return true;
    }

} // namespace logger
