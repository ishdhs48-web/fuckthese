#include "aim.h"
#include "holy/ui/cfg.hpp"
#include "holy/ui/holy_bridge.hpp"
#include "game/game.hpp"
#include "game/player.hpp"
#include "math.hpp"
#include "imgui.h"
#include "other/memory.hpp"
#include "logger.h"
#include <cmath>
#include <algorithm>
#include <chrono>

namespace aim {

    static constexpr float kPi = 3.14159265f;
    static constexpr float kVerticalFovDeg = 70.f;

    static constexpr uint64_t kOffPlayerAimController   = 0x80;
    static constexpr uint64_t kOffAimingData            = 0x90;
    static constexpr uint64_t kOffAimingDataPitch       = 0x18;
    static constexpr uint64_t kOffAimingDataYaw         = 0x1C;

    static auto g_lastWrite = std::chrono::steady_clock::now();
    static constexpr int WRITE_INTERVAL_MS = 16;

    static const uint64_t g_boneOffsets[] = { 0x20, 0x28, 0x30, 0x88 }; // head, neck, spine, pelvis

    // triggerbot scan state
    static bool g_trigger_on_target = false;
    static bool g_trigger_visible = false;

    static bool likely_ptr(uint64_t p) {
        return p > 0x10000ull && p < 0x0000FFFFFFFFFFFFull;
    }

    static float fov_radius_px(float fov_deg, float screen_h) {
        if (screen_h <= 0.f) return 0.f;
        float clamped = std::clamp(fov_deg, 1.f, 179.f);
        float half_vert = (kVerticalFovDeg * 0.5f) * (kPi / 180.f);
        float half_aim = (clamped * 0.5f) * (kPi / 180.f);
        float tan_v = std::tan(half_vert);
        if (std::fabs(tan_v) < 0.00001f) return 0.f;
        return ((screen_h * 0.5f) / tan_v) * std::tan(half_aim);
    }

    static float normalize_yaw(float yaw) {
        while (yaw > 180.f) yaw -= 360.f;
        while (yaw < -180.f) yaw += 360.f;
        return yaw;
    }

    static Vector3 get_bone_position(uint64_t p, int bone_idx) {
        uint64_t charView = rpm<uint64_t>(p + 0x48);
        if (!likely_ptr(charView)) return Vector3(0, 0, 0);
        uint64_t bipedMap = rpm<uint64_t>(charView + 0x48);
        if (!likely_ptr(bipedMap)) return Vector3(0, 0, 0);
        uint64_t boneTr = rpm<uint64_t>(bipedMap + g_boneOffsets[std::clamp(bone_idx, 0, 3)]);
        if (!likely_ptr(boneTr)) return Vector3(0, 0, 0);
        return player::get_transform_position(boneTr);
    }

    static bool pass_visible_check(uint64_t p) {
        if (!cfg::combat::aimbot_visible) return true;
        if (player::health(p) <= 0) return false;
        uint64_t occ = rpm<uint64_t>(p + 0xB8);
        if (likely_ptr(occ)) {
            if (rpm<int>(occ + 0x34) != 2 || rpm<int>(occ + 0x38) == 1) return false;
        }
        return true;
    }

    // triggerbot: fire button write when crosshair rests on an enemy bone
    static void triggerbot_tick(uint64_t lp) {
        if (!cfg::combat::triggerbot) return;

        // fire button lives under weapon root -> active weapon -> controller
        uint64_t wrc = rpm<uint64_t>(lp + 0x88);
        if (!likely_ptr(wrc)) return;
        uint64_t w = rpm<uint64_t>(wrc + 0xA0);
        if (!likely_ptr(w)) return;
        uint64_t btn = rpm<uint64_t>(w + 0x148);
        if (!likely_ptr(btn)) return;

        static bool pressing = false;

        // reuse the last aimbot scan: if crosshair within trigger px of a bone -> press
        ImVec2 center(g_sw * 0.5f, g_sh * 0.5f);
        bool on_target = g_trigger_on_target && (!cfg::combat::trigger_visible_only || g_trigger_visible);
        float range_px = 20.f;

        if (on_target) {
            if (!pressing) {
                wpm<uint8_t>(btn, 1);
                pressing = true;
            }
        } else if (pressing) {
            wpm<uint8_t>(btn, 0);
            pressing = false;
        }
    }

    void run() {
        if (!cfg::combat::aimbot && !cfg::combat::triggerbot) return;

        uint64_t pm = get_player_manager();
        if (!likely_ptr(pm)) return;

        uint64_t lp = rpm<uint64_t>(pm + 0x70);
        if (!likely_ptr(lp)) return;

        matrix vm = player::view_matrix(lp);
        Vector3 cam_pos = player::position(lp);

        uint64_t ac = rpm<uint64_t>(lp + kOffPlayerAimController);
        if (!likely_ptr(ac)) return;

        uint64_t camTr = rpm<uint64_t>(ac + 0x80);
        if (likely_ptr(camTr)) {
            Vector3 cp = player::get_transform_position(camTr);
            if (cp.x != 0.f || cp.y != 0.f || cp.z != 0.f) cam_pos = cp;
        }

        int lp_team = rpm<uint8_t>(lp + 0x79);

        uint64_t plist = rpm<uint64_t>(pm + 0x28);
        if (!likely_ptr(plist)) return;
        int pcount = rpm<int>(plist + 0x20);
        if (pcount <= 0 || pcount > 128) return;
        uint64_t buf = rpm<uint64_t>(plist + 0x18);
        if (!likely_ptr(buf)) return;

        ImVec2 center(g_sw * 0.5f, g_sh * 0.5f);
        float radius = fov_radius_px(cfg::combat::aimbot_fov, g_sh);
        float best_fov = radius;
        uint64_t best_target = 0;
        Vector3 best_bone(0, 0, 0);
        ImVec2 best_screen(0, 0);
        bool found = false;

        int targetBone = std::clamp(cfg::combat::aimbot_hitbox, 0, 3);

        // reset trigger scan state
        g_trigger_on_target = false;
        g_trigger_visible = false;
        float trigger_px = cfg::combat::trigger_range * (g_sh / 100.f); // rough m->px
        if (trigger_px < 8.f) trigger_px = 8.f;
        if (trigger_px > 80.f) trigger_px = 80.f;

        for (int i = 0; i < pcount; i++) {
            uint64_t p = rpm<uint64_t>(buf + 0x30 + 0x18 * i);
            if (!likely_ptr(p) || p == lp) continue;
            if (rpm<uint8_t>(p + 0x79) == lp_team) continue;
            if (player::health(p) <= 0) continue;
            bool vis = pass_visible_check(p);
            if (!vis) continue;

            Vector3 tp = get_bone_position(p, targetBone);
            if (tp.x == 0.f && tp.y == 0.f && tp.z == 0.f) continue;

            ImVec2 sp;
            if (!world_to_screen(tp, vm, sp)) continue;

            float dx = sp.x - center.x, dy = sp.y - center.y;
            float dist = std::sqrt(dx * dx + dy * dy);

            if (cfg::combat::aimbot && dist < best_fov) {
                best_fov = dist;
                best_target = p;
                best_bone = tp;
                best_screen = sp;
                found = true;
            }
            if (cfg::combat::triggerbot && dist < trigger_px) {
                g_trigger_on_target = true;
                g_trigger_visible = vis;
            }
        }

        // triggerbot works even without aimbot
        if (cfg::combat::triggerbot) triggerbot_tick(lp);

        if (!cfg::combat::aimbot) return;

        if (!found) {
            combat::has_target = false;
            combat::target_dist = 0.f;
            if (logger::throttle("aim_no_target", 5000)) logger::log("aim: no target in FOV (%.0fpx)", radius);
            return;
        }
        combat::has_target = true;
        combat::target_ptr = best_target;
        combat::target_dist = (best_bone - cam_pos).magnitude();
        if (logger::throttle("aim_target", 2000))
            logger::log("aim: target 0x%llx bone=(%.2f, %.2f, %.2f) screen=(%.0f, %.0f) dist=%.0fpx",
                        (unsigned long long)best_target, best_bone.x, best_bone.y, best_bone.z,
                        best_screen.x, best_screen.y, best_fov);

        ImDrawList* dl = ImGui::GetBackgroundDrawList();
        if (dl) {
            if (cfg::combat::aimbot_lock_line) {
                dl->AddLine(center, best_screen, IM_COL32(0, 0, 0, 180), 2.f);
                dl->AddLine(center, best_screen, IM_COL32(255, 255, 255, 220), 1.f);
            }
            if (cfg::combat::aimbot_lock_dot) {
                dl->AddCircleFilled(best_screen, 3.5f, IM_COL32(255, 255, 255, 230), 12);
            }
        }

        uint64_t ad = rpm<uint64_t>(ac + kOffAimingData);
        if (!likely_ptr(ad)) return;

        float curPitch = rpm<float>(ad + kOffAimingDataPitch);
        float curYaw = normalize_yaw(rpm<float>(ad + kOffAimingDataYaw));

        Vector3 dir = best_bone - cam_pos;
        float dist = dir.magnitude();
        if (dist < 0.1f) return;

        float rad2deg = 57.2957795f;
        float tgtPitch = -std::asin(std::clamp(dir.y / dist, -1.f, 1.f)) * rad2deg;
        float tgtYaw = normalize_yaw(std::atan2(dir.x, dir.z) * rad2deg);

        float pitch, yaw;
        float smooth = cfg::combat::aimbot_smooth; // legacy 1..20: 1 = instant
        if (smooth <= 1.05f) {
            pitch = tgtPitch;
            yaw = tgtYaw;
        } else {
            float step = 1.0f / smooth;
            pitch = curPitch + (tgtPitch - curPitch) * step;
            float d = tgtYaw - curYaw;
            while (d > 180.f) d -= 360.f;
            while (d < -180.f) d += 360.f;
            yaw = curYaw + d * step;
        }

        pitch = std::clamp(pitch, -89.f, 89.f);

        auto now = std::chrono::steady_clock::now();
        if (std::chrono::duration_cast<std::chrono::milliseconds>(now - g_lastWrite).count() >= WRITE_INTERVAL_MS) {
            g_lastWrite = now;
            bool ok1 = wpm<float>(ad + kOffAimingDataPitch, pitch);
            bool ok2 = wpm<float>(ad + kOffAimingDataYaw, yaw);
            bool ok3 = wpm<float>(ad + 0x24, pitch);
            bool ok4 = wpm<float>(ad + 0x28, yaw);
            if (logger::throttle("aim_write", 2000))
                logger::log("aim: write pitch=%.1f yaw=%.1f (ad=0x%llx) ok=%d%d%d%d",
                            pitch, yaw, (unsigned long long)ad, ok1, ok2, ok3, ok4);
        }
    }

    void draw_fov(ImDrawList* draw, float screen_w, float screen_h) {
        if (!draw || !cfg::combat::aimbot || !cfg::combat::aimbot_fov_draw || screen_w <= 0.f) return;
        float cx = screen_w * 0.5f, cy = screen_h * 0.5f;
        float radius = fov_radius_px(cfg::combat::aimbot_fov, screen_h);
        draw->AddCircle(ImVec2(cx, cy), radius, IM_COL32(0, 0, 0, 130), 64, 2.f);
        draw->AddCircle(ImVec2(cx, cy), radius, IM_COL32(255, 255, 255, 220), 64, 1.f);
    }

} // namespace aim
