#define IMGUI_DEFINE_MATH_OPERATORS
#include "menu.hpp"
#include "bar.hpp"
#include "cfg.hpp"
#include "theme/theme.hpp"
#include "holy_bridge.hpp"
#include "imgui.h"
#include "imgui_internal.h"
#include "logger.h"
#include <vector>
#include <string>
#include <ctime>
#include <cstdlib>
#include <cstdio>
#include <cmath>

extern ImFont* fontBold;
extern ImFont* fontMedium;
extern ImFont* fontDesc;
extern ImFont* espFont;
extern ImGuiWindow* g_window;

namespace ui::menu {
    static bool g_style_init = false;
    static int g_tab = 1;
    static float g_alpha = 0.f;
    static ImFont* g_font_body = nullptr;
    static ImFont* g_font_tabs = nullptr;
    static ImFont* g_font_title = nullptr;
    static bool g_should_exit = false;
    static bool g_menu_open = false;

    // Константы размеров — адаптив под экран (landscape: g_sw >= g_sh)
    static float WIN_WIDTH  = 1100.f;
    static float WIN_HEIGHT = 620.f;
    static const float TITLE_HEIGHT  = 52.f;
    static const float TABS_HEIGHT   = 70.f;
    static float CONTENT_OFFSET = TITLE_HEIGHT + TABS_HEIGHT + 30.f;

    static void fit_window() {
        float w = g_sw * 0.92f;
        float h = g_sh * 0.90f;
        if (w > 1100.f) w = 1100.f;
        if (h > 620.f) h = 620.f;
        if (w < 850.f) w = g_sw * 0.95f; // narrow screens: allow below min
        if (h < 500.f) h = g_sh * 0.95f;
        WIN_WIDTH = w;
        WIN_HEIGHT = h;
        CONTENT_OFFSET = TITLE_HEIGHT + TABS_HEIGHT + 30.f;
    }

    // Watermark
    static const float WM_PAD    = 12.f;
    static const float WM_HEIGHT = 38.f;   // нормальный размер

    static float lerp_float(float a, float b, float t) {
        return a + (b - a) * t;
    }

    static void init_style() {
        if (g_style_init) return;

        ImGuiStyle& style = ImGui::GetStyle();
        ImGui::StyleColorsDark();

        style.WindowBorderSize    = 1.f;
        style.ChildBorderSize     = 1.f;
        style.FrameBorderSize     = 1.f;
        style.WindowRounding      = 0.f;
        style.ChildRounding       = 0.f;
        style.FrameRounding       = 0.f;
        style.PopupRounding       = 0.f;
        style.ScrollbarRounding   = 0.f;
        style.GrabRounding        = 0.f;

        style.Colors[ImGuiCol_Text]                = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
        style.Colors[ImGuiCol_TextDisabled]        = ImVec4(0.50f, 0.50f, 0.50f, 1.00f);
        style.Colors[ImGuiCol_WindowBg]            = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
        style.Colors[ImGuiCol_ChildBg]             = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
        style.Colors[ImGuiCol_PopupBg]             = ImVec4(0.08f, 0.08f, 0.08f, 0.94f);
        style.Colors[ImGuiCol_Border]              = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
        style.Colors[ImGuiCol_BorderShadow]        = ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
        style.Colors[ImGuiCol_FrameBg]             = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
        style.Colors[ImGuiCol_FrameBgHovered]      = ImVec4(0.07f, 0.07f, 0.07f, 1.00f);
        style.Colors[ImGuiCol_FrameBgActive]       = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
        style.Colors[ImGuiCol_TitleBg]             = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
        style.Colors[ImGuiCol_TitleBgActive]       = ImVec4(0.16f, 0.29f, 0.48f, 1.00f);
        style.Colors[ImGuiCol_MenuBarBg]           = ImVec4(0.14f, 0.14f, 0.14f, 1.00f);
        style.Colors[ImGuiCol_ScrollbarBg]         = ImVec4(0.02f, 0.02f, 0.02f, 0.53f);
        style.Colors[ImGuiCol_ScrollbarGrab]       = ImVec4(0.31f, 0.31f, 0.31f, 1.00f);
        style.Colors[ImGuiCol_ScrollbarGrabHovered]= ImVec4(0.41f, 0.41f, 0.41f, 1.00f);
        style.Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.51f, 0.51f, 0.51f, 1.00f);
        style.Colors[ImGuiCol_CheckMark]           = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
        style.Colors[ImGuiCol_SliderGrab]          = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
        style.Colors[ImGuiCol_SliderGrabActive]    = ImVec4(1.00f, 1.00f, 1.00f, 1.00f);
        style.Colors[ImGuiCol_Button]              = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
        style.Colors[ImGuiCol_ButtonHovered]       = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
        style.Colors[ImGuiCol_ButtonActive]        = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
        style.Colors[ImGuiCol_Header]              = ImVec4(0.06f, 0.06f, 0.06f, 1.00f);
        style.Colors[ImGuiCol_HeaderHovered]       = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
        style.Colors[ImGuiCol_HeaderActive]        = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
        style.Colors[ImGuiCol_Separator]           = ImVec4(0.20f, 0.20f, 0.20f, 1.00f);
        style.Colors[ImGuiCol_ResizeGrip]          = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
        style.Colors[ImGuiCol_ResizeGripHovered]   = ImVec4(0.25f, 0.25f, 0.25f, 1.00f);
        style.Colors[ImGuiCol_ResizeGripActive]    = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
        style.Colors[ImGuiCol_TextSelectedBg]      = ImVec4(0.26f, 0.59f, 0.98f, 0.35f);
        style.Colors[ImGuiCol_ModalWindowDimBg]    = ImVec4(0.05f, 0.05f, 0.05f, 0.65f);

        // Аккуратные паддинги — чуть плотнее чем было
        style.WindowPadding = ImVec2(16.f, 16.f);
        style.FramePadding  = ImVec2(8.f, 4.f);
        style.ItemSpacing   = ImVec2(12.f, 10.f);  // было 15/15 — слишком разреженно
        style.ScrollbarSize = 20.f;

        // Шрифтовая иерархия:
        // fontBold   → заголовок меню + ватермарк (жирный)
        // fontMedium → табы
        // fontDesc   → тело (основной контент)
        g_font_title = fontBold   ? fontBold   : ImGui::GetFont();
        g_font_tabs  = fontMedium ? fontMedium : ImGui::GetFont();
        g_font_body  = fontDesc   ? fontDesc   : ImGui::GetFont();

        g_style_init = true;
    }

    static bool begin_window() {
        fit_window();
        ImVec2 win_size(WIN_WIDTH, WIN_HEIGHT);
        ImVec2 min_size(ImMin(850.f, WIN_WIDTH), ImMin(500.f, WIN_HEIGHT));
        ImGui::SetNextWindowSizeConstraints(min_size, win_size);
        ImGui::SetNextWindowSize(win_size, ImGuiCond_Always);
        ImGui::SetNextWindowPos(
            ImVec2((g_sw - win_size.x) * 0.5f, (g_sh - win_size.y) * 0.5f),
            ImGuiCond_Always);

        if (!ImGui::Begin("picadff", nullptr,
            ImGuiWindowFlags_NoTitleBar |
            ImGuiWindowFlags_NoScrollbar |
            ImGuiWindowFlags_NoCollapse))
            return false;

        g_window = ImGui::GetCurrentWindow();

        // Многослойная рамка — идентично оригиналу
        for (int i = 0; i < 8; ++i) {
            ImColor bc(0, 0, 0, 255);
            if      (i == 1 || i == 7) bc = ImColor(55, 55, 55, 255);
            else if (i == 0)            bc = ImColor(0,  0,  0,  255);
            else                        bc = ImColor(35, 35, 35, 255);

            ImGui::GetWindowDrawList()->AddRect(
                ImVec2(ImGui::GetWindowPos().x + (float)i, ImGui::GetWindowPos().y + (float)i),
                ImVec2(ImGui::GetWindowPos().x + ImGui::GetWindowSize().x - (float)i,
                       ImGui::GetWindowPos().y + ImGui::GetWindowSize().y - (float)i),
                bc);
        }
        return true;
    }

    static void end_window() { ImGui::End(); }

    static bool begin_section(const char* label, const ImVec2& size) {
        if (!ImGui::BeginChild(label, size, ImGuiChildFlags_Border,
            ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse))
            return false;

        const ImVec2 pos      = ImGui::GetWindowPos();
        const ImVec2 sz       = ImGui::GetWindowSize();
        const ImVec2 lsz      = ImGui::CalcTextSize(label);
        const ImVec2 lpos(pos.x + 15.f, pos.y - (lsz.y * 0.5f));

        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddRect(pos, ImVec2(pos.x + sz.x, pos.y + sz.y), ImColor(0,0,0,255));
        dl->AddRect(
            ImVec2(pos.x + 1.f, pos.y + 1.f),
            ImVec2(pos.x + sz.x - 1.f, pos.y + sz.y - 1.f),
            ImColor(40, 40, 40, 255));
        dl->AddRect(
            ImVec2(pos.x + 2.f, pos.y + 2.f),
            ImVec2(pos.x + sz.x - 2.f, pos.y + sz.y - 2.f),
            ImColor(25, 25, 25, 255));

        // Подложка под лейбл секции + сам лейбл
        ImGui::GetForegroundDrawList()->AddRectFilled(
            ImVec2(lpos.x - 4.f, lpos.y),
            ImVec2(lpos.x + lsz.x + 4.f, lpos.y + lsz.y),
            ImColor(15, 15, 15, 255));
        ImGui::GetForegroundDrawList()->AddText(lpos, ImColor(255, 255, 255, 255), label);

        return true;
    }

    static void end_section() { ImGui::EndChild(); }

    static void section_placeholder(const char* text) {
        ImGui::PushFont(g_font_body);
        ImGui::Spacing();
        ImGui::TextDisabled("%s", text);
        ImGui::PopFont();
    }

    static void begin_body_font() {
        if (g_font_body) ImGui::PushFont(g_font_body);
    }
    static void end_body_font() {
        if (g_font_body) ImGui::PopFont();
    }

    static void draw_separator() { ImGui::Separator(); }

    // popup-free combo replacement: combo popups crash the overlay backend, so we cycle
    static bool combo_from_vector(const char* label, int* current_item,
                                  const std::vector<const char*>& items) {
        if (items.empty()) return false;
        int idx = *current_item;
        if (idx < 0 || idx >= (int)items.size()) idx = 0;

        ImGui::PushID(label);
        bool changed = false;
        if (ImGui::Button("<")) {
            idx = (idx == 0) ? (int)items.size() - 1 : idx - 1;
            changed = true;
        }
        ImGui::SameLine();
        ImGui::Text("%s: %s", label, items[idx]);
        ImGui::SameLine();
        if (ImGui::Button(">")) {
            idx = (idx + 1) % (int)items.size();
            changed = true;
        }
        if (changed) *current_item = idx;
        ImGui::PopID();
        return changed;
    }

    static void color_control(const char* label, ImVec4* value) {
        ImGui::TextUnformatted(label);
        ImGui::SetNextItemWidth(-1.f);
        std::string id = std::string("##") + label;
        ImGui::ColorEdit4(id.c_str(), &value->x,
            ImGuiColorEditFlags_NoInputs |
            ImGuiColorEditFlags_AlphaBar |
            ImGuiColorEditFlags_AlphaPreviewHalf);
    }

    static ImVec2 content_half_size() {
        return ImVec2(
            (ImGui::GetWindowSize().x -
             (ImGui::GetStyle().WindowPadding.x * 2.f + ImGui::GetStyle().ItemSpacing.x)) * 0.5f,
            ImGui::GetWindowSize().y - CONTENT_OFFSET -
             (ImGui::GetStyle().WindowPadding.y * 2.f + ImGui::GetStyle().ItemSpacing.y * 2.f));
    }

    // =============================== TABS ================================

    static void aimbot_tab() {
        const ImVec2 full_size(
            ImGui::GetWindowSize().x - (ImGui::GetStyle().WindowPadding.x * 2.f),
            content_half_size().y);

        if (begin_section("aimbot", full_size)) {
            begin_body_font();

            ImGui::Checkbox("Enable Aimbot", &cfg::combat::aimbot);
            if (cfg::combat::aimbot) {
                combo_from_vector("Target bone", &cfg::combat::aimbot_hitbox,
                    std::vector<const char*>{"Head", "Chest", "Spine", "Pelvis"});

                ImGui::Checkbox("Visible only", &cfg::combat::aimbot_visible);
                ImGui::SliderFloat("FOV (deg)", &cfg::combat::aimbot_fov, 5.f, 180.f, "%.0f");
                ImGui::SliderFloat("Smooth", &cfg::combat::aimbot_smooth, 1.f, 20.f, "%.1f");

                draw_separator();

                ImGui::Checkbox("Show FOV circle", &cfg::combat::aimbot_fov_draw);
                ImGui::Checkbox("Show lock line", &cfg::combat::aimbot_lock_line);
                ImGui::Checkbox("Show lock dot", &cfg::combat::aimbot_lock_dot);
            }

            draw_separator();

            // ---------- AIM STATUS (read-only) ─────────
            ImGui::TextDisabled("Aimbot state");
            {
                const char* status = combat::aimbot_status_label();
                const char* bone   = combat::aimbot_resolved_label();
                bool        has_t  = combat::aimbot_has_target();
                float       dist   = combat::aimbot_target_distance();

                ImVec4 col = has_t ? ImVec4(0.65f, 0.95f, 0.65f, 1.f)
                                   : ImVec4(0.65f, 0.65f, 0.65f, 1.f);
                ImGui::TextColored(col, "Status: %s", status ? status : "Idle");
                if (has_t) {
                    ImGui::Text("Bone:   %s", bone ? bone : "?");
                    ImGui::Text("Dist:   %.0f m", dist);
                }
            }

            end_body_font();
        }
        end_section();
    }

    static void visuals_tab() {
        const ImVec2 child_size = content_half_size();

        if (begin_section("esp", child_size)) {
            begin_body_font();
            ImGui::Checkbox("Box 2D",          &cfg::esp::box);
            ImGui::Checkbox("Box 3D",          &cfg::esp::box3d);
            ImGui::Checkbox("Name",            &cfg::esp::name);
            ImGui::Checkbox("Health bar",      &cfg::esp::health);
            ImGui::Checkbox("Distance",        &cfg::esp::distance);
            ImGui::Checkbox("Head dot",        &cfg::esp::head_dot);
            ImGui::Checkbox("Snapline",        &cfg::esp::snapline);
            ImGui::Checkbox("Snapline head",   &cfg::esp::snapline_head);
            draw_separator();
            combo_from_vector("Box type", &cfg::esp::box_type,
                std::vector<const char*>{"Full", "Corner"});
            ImGui::SliderFloat("Box rounding", &cfg::esp::box_rounding, 0.f, 10.f, "%.0f");
            end_body_font();
        }
        end_section();

        ImGui::SameLine();

        if (begin_section("colors", child_size)) {
            begin_body_font();
            color_control("Box color",       &cfg::esp::box_col);
            color_control("Name color",      &cfg::esp::name_col);
            color_control("Health color",    &cfg::esp::health_col);
            color_control("Distance color",  &cfg::esp::distance_col);
            color_control("Head dot color",  &cfg::esp::head_dot_col);
            color_control("Snapline color",  &cfg::esp::snapline_col);
            end_body_font();
        }
        end_section();
    }

    static void reset_cfg() {
        cfg::esp::box          = false;
        cfg::esp::name         = false;
        cfg::esp::health       = false;
        cfg::esp::distance     = false;
        cfg::esp::head_dot     = false;
        cfg::esp::snapline     = false;
        cfg::esp::snapline_head = false;
        cfg::esp::box_type     = 0;
        cfg::esp::box_rounding = 0.f;
        cfg::esp::box_col      = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
        cfg::esp::name_col     = ImVec4(1.f, 1.f, 1.f, 1.f);
        cfg::esp::health_col   = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
        cfg::esp::distance_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
        cfg::esp::head_dot_col = ImVec4(225/255.f, 144/255.f, 144/255.f, 1.f);
        cfg::esp::snapline_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);

        cfg::combat::aimbot           = false;
        cfg::combat::aimbot_visible   = true;
        cfg::combat::aimbot_fov       = 60.f;
        cfg::combat::aimbot_smooth    = 5.f;
        cfg::combat::aimbot_fov_draw  = true;
        cfg::combat::aimbot_lock_line = true;
        cfg::combat::aimbot_lock_dot  = true;
        cfg::combat::aimbot_hitbox    = 0;
    }

    static void config_tab() {
        const ImVec2 child_size = content_half_size();

        if (begin_section("info", child_size)) {
            begin_body_font();
            char buffer[64];
            std::snprintf(buffer, sizeof(buffer), "Cheat: TeamRatko v1.0");
            ImGui::TextUnformatted(buffer);
            std::snprintf(buffer, sizeof(buffer), "Game: Standoff 2 v0.39.2");
            ImGui::TextUnformatted(buffer);
            std::snprintf(buffer, sizeof(buffer), "Screen: %.0f x %.0f", g_sw, g_sh);
            ImGui::TextUnformatted(buffer);
            std::snprintf(buffer, sizeof(buffer), "FPS: %.0f", ImGui::GetIO().Framerate);
            ImGui::TextUnformatted(buffer);
            end_body_font();
        }
        end_section();

        ImGui::SameLine();

        if (begin_section("action", child_size)) {
            begin_body_font();
            if (ImGui::Button("Reset settings", ImVec2(-1.f, 0.f)))
                reset_cfg();
            if (ImGui::Button("Exit", ImVec2(-1.f, 0.f)))
                g_should_exit = true;
            end_body_font();
        }
        end_section();
    }

    static void render_current_tab() {
        if (logger::throttle("tab_render", 2000))
            logger::log("ui: rendering tab %d", g_tab);
        switch (g_tab) {
            case 0: aimbot_tab();   break;
            case 1: visuals_tab();  break;
            case 2: config_tab();   break;
            default: visuals_tab(); break;
        }
    }

    static void render_bottom_tabs() {
        const char* names[3] = {"aim", "visuals", "config"};

        if (!begin_section("  ",
            ImVec2(ImGui::GetWindowSize().x - (ImGui::GetStyle().WindowPadding.x * 2.f),
                   TABS_HEIGHT)))
            return;

        // fontBold для табов — чуть жирнее чем medium
        if (g_font_tabs) ImGui::PushFont(g_font_tabs);

        for (int i = 0; i < 3; ++i) {
            char tab_name[32];
            std::snprintf(tab_name, sizeof(tab_name), "%s##%d", names[i], i);

            if (g_tab == i)
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(255, 255, 255, 255));
            else
                ImGui::PushStyleColor(ImGuiCol_Text, IM_COL32(160, 160, 160, 255));

            ImGui::PushStyleVar(ImGuiStyleVar_SelectableTextAlign, ImVec2(0.5f, 0.5f));

            if (ImGui::Selectable(
                    tab_name, g_tab == i, 0,
                    ImVec2(ImMax(ImGui::GetWindowSize().x / 3.f -
                           (ImGui::GetStyle().FramePadding.x + ImGui::GetStyle().WindowPadding.x), 60.f),
                           0.f))) {
                logger::log("ui: tab -> %s", names[i]);
                g_tab = i;
            }

            ImGui::PopStyleVar();
            ImGui::PopStyleColor();

            if (i != 2) ImGui::SameLine();
        }

        if (g_font_tabs) ImGui::PopFont();

        end_section();
    }

    // ============================================================
    // WATERMARK — ЛЕВАЯ СТОРОНА, ЧЁРНЫЙ ФОН, ЖИРНЫЙ ШРИФТ
    // ============================================================

    void render_watermark(float alpha) {
        if (alpha < 0.001f) return;

        // Средний шрифт: fontMedium если есть, иначе espFont
        ImFont* wm_font = fontMedium ? fontMedium : (espFont ? espFont : nullptr);
        if (!wm_font) return;

        const float FONT_SIZE = 15.f;   // средний размер — не слишком крупно, не мелко
        const float PAD_X     = 30.f;
        const float PAD_Y     = 10.f;
        const float BG_H      = 50.f;   // высота плашки

        ImDrawList* dl = ImGui::GetForegroundDrawList();

        char wm_text[64];
        std::snprintf(wm_text, sizeof(wm_text), "TeamRatko  |  %.0f fps", ImGui::GetIO().Framerate);

        ImVec2 text_size = wm_font->CalcTextSizeA(FONT_SIZE, FLT_MAX, 0.f, wm_text);

        float bg_w = text_size.x + PAD_X * 2.f + 6.f;  // +6 под акцент-полосу

        // Верхний левый угол экрана с небольшим отступом
        const float OFF = 10.f;
        ImVec2 bg_min(OFF, OFF);
        ImVec2 bg_max(OFF + bg_w, OFF + BG_H);

        // Фон
        dl->AddRectFilled(bg_min, bg_max, IM_COL32(8, 8, 8, (int)(230 * alpha)), 4.f);

        // Левая акцентная полоска 3px
        dl->AddRectFilled(
            ImVec2(bg_min.x + 1.f, bg_min.y + 4.f),
            ImVec2(bg_min.x + 4.f, bg_max.y - 4.f),
            IM_COL32(162, 144, 225, (int)(255 * alpha)), 2.f);

        // Внешняя рамка
        dl->AddRect(bg_min, bg_max,
            IM_COL32(35, 35, 35, (int)(220 * alpha)), 4.f, 0, 1.f);

        // Позиция текста: вертикально по центру, горизонтально после полоски
        ImVec2 text_pos(
            bg_min.x + PAD_X + 4.f,
            bg_min.y + (BG_H - text_size.y) * 0.5f);

        // Тень
        dl->AddText(wm_font, FONT_SIZE,
            ImVec2(text_pos.x + 1.f, text_pos.y + 1.f),
            IM_COL32(0, 0, 0, (int)(120 * alpha)), wm_text);

        // Текст: имя белое, FPS немного приглушён
        // Рисуем одной строкой — красить части отдельно не нужно
        dl->AddText(wm_font, FONT_SIZE, text_pos,
            IM_COL32(225, 225, 225, (int)(255 * alpha)), wm_text);

        // --- Кликабельная зона ---
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, 0.f);
        ImGui::SetNextWindowPos(bg_min);
        ImGui::SetNextWindowSize(ImVec2(bg_w, BG_H));
        ImGui::Begin("##wm_click", nullptr,
            ImGuiWindowFlags_NoTitleBar     |
            ImGuiWindowFlags_NoDecoration   |
            ImGuiWindowFlags_NoBackground   |
            ImGuiWindowFlags_NoMove         |
            ImGuiWindowFlags_NoResize       |
            ImGuiWindowFlags_NoScrollbar);

        if (ImGui::InvisibleButton("##wm_btn", ImVec2(bg_w, BG_H))) {
            g_menu_open     = !g_menu_open;
            ui::bar::g_open = g_menu_open;
        }

        ImGui::End();
        ImGui::PopStyleVar();
    }

    bool should_exit() { return g_should_exit; }

    void set_menu_open(bool open) {
        g_menu_open     = open;
        ui::bar::g_open = open;
    }

    bool is_menu_open() { return g_menu_open; }

    // ============================================================
    // MAIN RENDER
    // ============================================================

    void render() {
        if (g_should_exit) return;

        bar::render();
        init_style();

        const float dt = ImClamp(ImGui::GetIO().DeltaTime * 10.f, 0.f, 1.f);
        g_alpha = lerp_float(g_alpha, bar::g_open ? 1.f : 0.f, dt);

        if (g_alpha <= 0.01f) return;

        // Затемнение фона при открытом меню
        ImDrawList* bg = ImGui::GetBackgroundDrawList();
        bg->AddRectFilled(ImVec2(0.f, 0.f), ImVec2(g_sw, g_sh),
            IM_COL32(0, 0, 0, (int)(110.f * g_alpha)));

        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, g_alpha);

        if (begin_window()) {
            // --- Заголовок --- fontBold + чуть крупнее + жирный вид
            if (begin_section(" ",
                ImVec2(ImGui::GetWindowSize().x -
                       (ImGui::GetStyle().WindowPadding.x * 2.f), TITLE_HEIGHT))) {

                const char* label = "TeamRatko v1.0 | Standoff 2";

                // Используем fontBold для заголовка
                if (g_font_title) ImGui::PushFont(g_font_title);

                const ImVec2 ts = ImGui::CalcTextSize(label);
                const ImVec2 lpos(
                    (ImGui::GetWindowPos().x + ImGui::GetWindowSize().x * 0.5f) - (ts.x * 0.5f),
                    (ImGui::GetWindowPos().y + ImGui::GetWindowSize().y * 0.5f) - (ts.y * 0.5f));

                // Тень заголовка — глубина
                ImGui::GetWindowDrawList()->AddText(
                    ImVec2(lpos.x + 1.f, lpos.y + 1.f),
                    ImColor(0, 0, 0, (int)(180.f * g_alpha)), label);

                // Основной заголовок
                ImGui::GetWindowDrawList()->AddText(
                    lpos, ImColor(255, 255, 255, (int)(255.f * g_alpha)), label);

                if (g_font_title) ImGui::PopFont();
            }
            end_section();

            render_current_tab();
            render_bottom_tabs();
            end_window();
        }

        ImGui::PopStyleVar();
    }
}
