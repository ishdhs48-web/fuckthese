#pragma once
#include "imgui.h"

namespace cfg {

namespace esp {
    inline bool box            = false;
    inline bool name           = false;
    inline bool health         = false;
    inline bool distance       = false;
    inline bool snapline       = false;
    inline bool snapline_head  = false;
    inline bool hitlog         = false;
    inline bool head_dot       = false;
    inline bool box3d          = false;

    inline int   box_type     = 0;
    inline float box_rounding = 0.f;

    inline ImVec4 box_col           = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 name_col          = ImVec4(1.f, 1.f, 1.f, 1.f);
    inline ImVec4 health_col        = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 distance_col      = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 snapline_col      = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
    inline ImVec4 snapline_head_col = ImVec4(225/255.f, 144/255.f, 144/255.f, 1.f);
    inline ImVec4 head_dot_col      = ImVec4(225/255.f, 144/255.f, 144/255.f, 1.f);
    inline ImVec4 box3d_col         = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
}

namespace radar {
    inline bool  enabled   = false;
    inline float size      = 180.f;
    inline float range     = 100.f;
    inline float pos_x     = 0.f;
    inline float pos_y     = 0.f;
    inline ImVec4 bg_col   = ImVec4(6/255.f,  6/255.f,  6/255.f,  0.85f);
    inline ImVec4 dot_col  = ImVec4(225/255.f, 100/255.f, 100/255.f, 1.f);
    inline ImVec4 self_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
}

namespace info_panel {
    inline bool enabled = false;
}

namespace combat {
    // mirrors of our aim.cpp settings (aim.cpp reads these through holy_bridge)
    inline bool  aimbot               = false;
    inline bool  aimbot_visible       = true;
    inline float aimbot_fov           = 60.f;
    inline float aimbot_smooth        = 5.f;   // 1..20 (legacy scale)
    inline bool  aimbot_fov_draw      = true;
    inline bool  aimbot_lock_line     = true;
    inline bool  aimbot_lock_dot      = true;
    inline float aimbot_max_dist      = 250.f;
    inline int   aimbot_hitbox        = 0;    // 0=Head, 1=Chest
    inline bool  aimbot_allow_fallback = true;

    inline bool  triggerbot           = false;
    inline float trigger_delay        = 0.05f;
    inline float trigger_range        = 30.f;
    inline bool  trigger_visible_only = true;
}

namespace effects {
    inline bool death_particles = false;
    inline ImVec4 particle_col = ImVec4(162/255.f, 144/255.f, 225/255.f, 1.f);
}

namespace gfx {
    inline bool low_gfx        = false;
    inline bool texture_potato = false;
}

} // namespace cfg
