#pragma once
// bridge between holy menu and our aim backend
#include "cfg.hpp"
#include "cfg_holy.hpp"
#include <cstdint>

namespace combat {
    // live state, updated by aim.cpp
    inline bool     has_target = false;
    inline float    target_dist = 0.f;
    inline uint64_t target_ptr = 0;

    inline const char* aimbot_status_label() { return has_target ? "Locked" : "Idle"; }
    inline const char* aimbot_selected_label() { static char buf[48] = {}; return buf; }
    inline const char* aimbot_resolved_label() { return cfg::combat::aimbot_hitbox == 0 ? "Head" : "Chest"; }
    inline float       aimbot_target_distance() { return target_dist; }
    inline bool        aimbot_has_target() { return has_target; }
}

namespace gfx {
    // not ported to this build — menu toggles just flip cfg flags
    inline void low_gfx_on()  {}
    inline void low_gfx_off() {}
    inline void texture_on()  {}
    inline void texture_off() {}
}
