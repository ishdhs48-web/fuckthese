#pragma once
#include <cstdint>

// STANDOFF 2 v0.39.2 (arm64) — сверено с dump.cs
namespace sdk {

// PlayerManager : LazySingleton<PlayerManager>  (instance через TypeInfo, см. esp.cpp)
inline constexpr int PM_Dict        = 0x28;  // Dictionary<int, PlayerController>
inline constexpr int PM_LocalPlayer = 0x70;  // backing field (как у nez3rpw)

// il2cpp Dictionary<int, T*> — два поколения лэйаута, авто-детект в рантайме
// new: buckets 0x18, entries 0x20, count 0x24 | old: entries 0x18, count 0x20
inline constexpr int DICT_ENTRY_SZ  = 0x18;  // Entry{hash,next,key,value}
inline constexpr int DICT_ENTRY_VAL = 0x10;
inline constexpr int ARRAY_DATA     = 0x20;

// PlayerController
inline constexpr int PC_CAM_HOLDER      = 0x28;  // Transform (holder)
inline constexpr int PC_CHAR_VIEW_FPV   = 0x48;
inline constexpr int PC_CHAR_VIEW_TPV   = 0x50;
inline constexpr int PC_TEAM            = 0x79;  // enum byte
inline constexpr int PC_MAIN_CAMERA     = 0xE8;  // PlayerMainCamera
inline constexpr int PC_MOVEMENT        = 0x98;
inline constexpr int PC_OCCLUSION       = 0xB8;  // PlayerOcclusionController (v0.39.2)
inline constexpr int PC_PHOTON_PLAYER   = 0x160;

// PlayerCharacterView
inline constexpr int PCV_BIPED_MAP = 0x48;

// PlayerMainCamera
inline constexpr int PMC_CAMERA_COMPONENT = 0x20; // Camera

// Camera -> W2S matrix
inline constexpr int CAM_CACHED_PTR   = 0x10;    // il2cpp obj -> native
inline constexpr int CAM_NATIVE_MATRIX = 0xF0;   // view-proj matrix (nez3rpw-proven)

// MovementController -> fast root position
inline constexpr int MC_TRANSFORM_DATA = 0xB0;
inline constexpr int TD_POSITION       = 0x44;

// Occlusion (visibility)
inline constexpr int OCC_VISIBILITY = 0x34;
inline constexpr int OCC_STATE      = 0x38;
inline constexpr int PCV_ISVISIBLE  = 0x30;

// PhotonPlayer
inline constexpr int PP_NAME  = 0x20;
inline constexpr int PP_PROPS = 0x38;
// CustomProperties registry walk
inline constexpr int PROPS_COUNT = 0x20;
inline constexpr int PROPS_LIST  = 0x18;
inline constexpr int PROPS_KEY   = 0x28;
inline constexpr int PROPS_VAL   = 0x30;
inline constexpr int PROPS_STRIDE = 0x18;

// BipedMap bones (Transform*), contiguous from 0x20
inline constexpr int BIPED_FIRST = 0x20;
inline constexpr int BIPED_COUNT = 22; // head..r_toe

// transform internals (nez3rpw-proven)
inline constexpr int TR_INTERNAL    = 0x10;
inline constexpr int TR_MATRIX_DATA = 0x28;
inline constexpr int TR_INDEX       = 0x30;
inline constexpr int MD_MATRIX_LIST = 0x18;
inline constexpr int MD_PARENT_IDX  = 0x20;

// Unity string
inline constexpr int STR_CHARS = 0x14;

} // namespace sdk
